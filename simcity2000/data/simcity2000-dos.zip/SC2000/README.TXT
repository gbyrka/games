SIMCITY 2000 (TM) Last Minute Info - !!PLEASE READ ME!! (1/12/94) 

I. **CREATING A BOOTDISK**
II. INSTALLATION
     Video Selection
     Sound Selection
III. VIDEO CARDS
     What Is A VESA Driver And How Do I Use It?
     ATI Ultra Pro or Mach 32 Video Cards
     Diamond Viper
     Trident Video Cards
IV. MOUSE DRIVERS
     Microsoft Compatible Mouse Required
V. SOUND CARDS
     What Are Miles Design Drivers And How Do I Use Them?
     SoundBlaster Installation
     Pro Audio Spectrum
     Gravis Ultrasound
     Aria Compatible Sound Cards
VI. MISCELLANEOUS
     Memory Issues
     Running with QEMM, EMM386 And Other Memory Managers
     Running SimCity 2000 Under OS/2
     Creating A Boot Disk With Stacker/DoubleSpace
VII. GAME PLAY ISSUES (READ THIS!)
     Saved Cities
     Micro-Simulators
     Terrain Editing
     Airports
     Newspapers
     Importing Cities From SimCity Classic and SimCity 2000 Mac
     Hot Keys
VIII. TROUBLESHOOTING
     I Get An "Error 35"
     SimCity 2000 Locks Up
     SimCity 2000 Install Program Crashes
     I Get A "Microsoft Compatible Mouse Not Found" Message
     I Have A Diamond Stealth/Viper And Get Funny Lines On My Display

Please read _ALL_ of this document! This stuff is important! 
 
It covers a lot about memory, installation, various graphics cards and 
sound cards, gameplay issues, importing cities from other versions of 
SimCity 2000, and hot keys.   
 
I. **CREATING A BOOTDISK**

  If you experience problems playing SimCity 2000 or receive messages
  that you do not have enough memory to play, you will probably need to 
  create a bootdisk.  A bootdisk lets your machine boot from a floppy 
  disk and will not load memory eating programs, freeing more memory up
  for SimCity 2000.  We have included a utility that will automatically 
  create bootdisks for you in this package.  To create a bootdisk, first 
  go to the \SC2000 directory.  For example if you installed SimCity 2000 
  to C:\SC2000, you would type 'CD SC2000' and hit return.  Then type 
  'BOOTDISK' and hit return.  If you follow the onscreen prompts, the
  program will create a bootdisk for you.  

II. INSTALLATION
 
Video Selection 
--------------- 
The SimCity 2000 installer will attempt to figure out what kind of 
video card you have in your machine. If it is not sure what kind of 
video card you have, or the installer detects a VESA driver in memory
(or in BIOS), it will default to the VESA SUPER VGA driver. You can 
click on the arrow to the right of the VESA SUPER VGA entry for a list 
of other cards that the installer thinks you might have. If your card 
is on this list, you can select it instead of the default VESA driver.
If the installer cannot figure out what kind of card you have and
cannot detect a VESA driver, a large red warning message will be 
displayed. If you wish to continue and try to run SimCity 2000 anyway,
you MUST load some type of VESA driver for your video card.

Sound Selection 
--------------- 
SimCity 2000 cannot automatically detect what kind of sound card you 
have in your machine. You will need to pick your sound card(s) 
out of the lists provided. The installer will then try to verify the 
presence of that sound card in your machine. Certain hardware settings
on your card may be different from what SimCity 2000 is expecting. To
change these settings, select the Change Settings option from the sound
card verification window (where it says "OK" or "Failed!"). For more
information on these hardware settings, see the manual that came with
your sound card. If your sound card is not shown and is 100 percent 
SoundBlaster compatible, you should be able to install for SoundBlaster 
and hear sound and music. See the section on Miles Design Drivers below 
for information on what to do if your sound card is not supported.
 
III. VIDEO CARDS

What Is A VESA Driver And How Do I Use It?
------------------------------------------
VESA stands for Video Electronics Standards Association. It is a 
standard that allows software companies to write programs that work
on many video cards without having to know how each card works.
The VESA driver is the program that handles this. Almost every video
card available today has VESA drivers available for it. These drivers
may be stored in a chip on the video card, or they may be a program
that the user has to load by hand (or with a batch file). Some cards 
(such as the Diamond Viper) have the driver on the video card, but 
need the user to run a special program to activate the driver. During
installation of SimCity 2000, if the installer detects a VESA driver in
memory (or on the card), it will list VESA SUPER VGA as the default.
You may also be able to select specific video support for your card if
it is supported (we recommend using specific video support, if possible,
for fastest operation). If the VESA driver is an external program, it
will probably be found on the disks that came with your video card. 
If you don't have a VESA driver you should contact your video card 
manufacturer. We have included VESA drivers for most popular cards in 
your SimCity 2000 directory. To find the particular driver for your 
system, look in the SC2000\VESA directory for the subdirectory that 
sounds closest to the name of your brand of video card. In that 
subdirectory should be the VESA driver. Using most 'external' 
(programs that you must run) VESA drivers is as easy as typing the 
name of the driver at the DOS prompt. For instance, if the driver were 
called VVESA.COM, you would type:
VVESA.COM [ENTER]

ATI Ultra Pro or Mach 32 Video Cards 
------------------------------------ 
If you have an ATI Ultra Pro or other card based on the Mach 32 chip,  
you must run the included utility MW_ATIUP.EXE before playing  
SimCity, for complete compatibility. 

Simply type:    MW_ATIUP [Enter] 
then type:      SC2000   [Enter] 
 
to use your ATI card with SimCity 2000. If the MW_ATIUP program is
not run, you may get an "ERROR 35" type message when trying to run
SimCity 2000. MW_ATIUP.EXE can be found in the SimCity 2000 directory.
 
Diamond Viper
-------------
The Diamond Viper has its VESA driver on the card, but you need to
run an external program to activate it. This program is called
VPRMODE.EXE. To use VPRMODE to activate the VESA driver, type:

VPRMODE VESA [ENTER]

The VPRMODE program should have been installed by the software that
came with the Diamond Viper card.

Trident Video Cards 
------------------- 
Some older Trident video cards may not be compatible with the Trident  
driver installed by SimCity 2000. If you installed a Trident video  
card and are experiencing video problems, try running the INSTALL.EXE  
program in the SimCity 2000 directory and selecting the VESA video 
driver, then install the proper VESA driver for the card before running
SimCity 2000.

IV. MOUSE DRIVERS

Microsoft Compatible Mouse Required
-----------------------------------
SimCity 2000 requires a Microsoft-compatible mouse to run. Most
mice today (including Logitech, Mouse Systems, and Kensington) are
Microsoft-compatible. In order for the mouse to work properly in
SimCity 2000, a mouse driver must be loaded before running
SimCity 2000. The mouse driver must also be fairly current and VESA 
compatible. Contact the manufacturer of your mouse or the dealer who 
sold the mouse to you to see if your driver is the most current
available.

V. SOUND CARDS

What Are Miles Design Drivers And How Do I Use Them?
---------------------------------------------------- 
SimCity 2000 sound support is accomplished through the use of the 
John Miles Design AIL audio driver libraries. Like VESA drivers, these
help software companies support many different sound cards without
having to know how each card works. The Miles Design Drivers are
automatically installed when you select which sound card you wish
to use for sound and music in SimCity 2000. If your sound card is 
not mentioned specifically in the installer, you may be able to get 
drivers from the manufacturer for full SimCity 2000 sound. 
SimCity 2000 requires "32-bit flat mode" Miles Design drivers. 
Non-32-bit drivers will not work.
 
SoundBlaster Installation
-------------------------
The SimCity 2000 Installer expects to find the SoundBlaster at IRQ 7. 
Many SoundBlasters are shipped with the default IRQ set to 5. If you 
have a SoundBlaster and the installer says "Sound Card Detection: 
FAILED!", click on the Change Settings button and enter 5 in the IRQ 
entry. The DMA and ADDR settings should be fine.

Pro Audio Spectrum 
------------------ 
MUSIC: The Music Driver for the Pro Audio Spectrum requires the Media 
Vision driver MVSOUND.SYS to be loaded in memory as a driver in  
your CONFIG.SYS file. If this driver is not loaded, you will receive a 
verification failure during installation, and you will NOT hear music 
during the game. For more information about MVSOUND.SYS, please 
refer to your Pro Audio Spectrum user's manual, or call Media Vision 
Technical Support. 
SOUND EFFECTS: If you choose Pro Audio Spectrum as your Sound 
Effects sound card, you may experience some sound effects "dropouts," 
or even no sound at all. This will only happen on some Pro Audio 
Spectrum sound cards. If this does happen, you can re-run the INSTALL 
program and choose SoundBlaster for the Sound Effects Card, instead 
of Pro Audio Spectrum. 
CAUTION:  This may or may not work depending on your Pro Audio 
Spectrum. Please call Media Vision Technical Support if you have more 
problems. 
 
Gravis Ultrasound 
----------------- 
SimCity 2000 is compatible with the SBOS SoundBlaster Emulation TSR 
for the GUS. However, most memory managers (such as EMM386) will cause
problems if they are loaded at the same time as SimCity 2000 and SBOS.
DO NOT attempt to run or even install SimCity 2000 with both SBOS and
a memory manager present. Bad things may happen. 
 
Aria Compatible Sound Cards
---------------------------
We now have Miles Design Drivers for all sound cards based on the 
ARIA Sound Synth by Sierra Semiconductor. These include: 
 
Viva Maestro 16  
VR Alpha Systems  
Cyber Audio  
Add Tech Sound 2000  
Sound Tower  
Cardinal Technologies Sound Pilot  
Diamond Computer Systems Sonic Sound  
Sonic Sound Pro  
Genoa Systems AudioBahn 
AudioBahn Listener  
Kingston Technologies Omnivox  
Zoltrix TESS 
and others... 

VI. MISCELLANEOUS

Memory Issues
------------- 
SimCity 2000 requires a lot of memory to run--4 MB total. On some 
machines, even if you have the required 4 MB, SimCity 2000 may report 
that you do not have enough free extended or conventional memory. If 
this is the case, your best alternative is to create a boot disk as 
outlined on page 6 of the SimCity 2000 DOS Addendum/Quick Start Guide. 
Another solution that may help is to install SimCity 2000 with No Sound 
and No Music selected. If you have already installed SimCity 2000, you 
can change your current sound, music, and video settings by running the 
INSTALL.EXE program in the SimCity 2000 directory. 
 
Running With QEMM, EMM386 And Other Memory Managers
----------------------------------------------------
We recommend that you not load any memory managers or disk cache 
utilities while running SimCity 2000, especially if you are using 
DOS 6 on a machine with only 4 MB RAM. 
If you are using a memory manager, you MUST NOT have it set in auto  
mode--this will cause a conflict with SimCity 2000. 
If you are using MS-DOS 6 and absolutely must load EMM386.EXE, 
you will need to either have the EMS size set to 'noems' or larger 
than 4096. See your DOS manual for information on how to do this. 
If you are running QEMM in Stealth mode, SimCity 2000 may fail to
recognize your VESA driver built into the video card BIOS. You will need
to run in Frame Mode as opposed to Page Mode. To do this, change the
"ST:M" parameter in your QEMM statement to "ST:F". See your QEMM manual
for more information on how to do this.

Running SimCity 2000 Under OS/2
-------------------------------
We have successfully run SimCity 2000 under a DOS session in OS/2. We
have not been able to run it as a migrated application. During
installation, you MUST NOT swap the installer to the background. It
must always be the foreground application until installation is complete.
If you have OS/2 and are able to run SimCity 2000 under MS-DOS but not
under OS/2, please call IBM Technical Support.

Creating A Boot Disk With Stacker/DoubleSpace
---------------------------------------------
Stacker version 3.0 and earlier require certain drivers to be loaded in 
the CONFIG.SYS file in order to mount the compressed hard drive.  When 
creating a boot disk with Stacker 3.0 and earlier you must include two 
lines in the CONFIG.SYS file.  The exact path is dependent upon where 
you installed Stacker on your hard disk, but here we will provide the 
path for the default installation of Stacker.  The two lines needed in 
your CONFIG.SYS file are:
DEVICE=C:\STACKER\STACKER.COM C:\STACVOL.DSK
DEVICE=C:\STACKER\SSWAP.COM C:\STACVOL.DSK

These lines will load Stacker and mount your compressed drive when 
booting from the boot disk.

DoubleSpace and Stacker 3.1 do not require that lines be added in the 
CONFIG.SYS file as they copy hidden files to the boot disk when using 
the "SYS A:" or "FORMAT A: /S" command.  Make a boot disk according to 
the normal instructions regarding creating a boot disk in your SimCity
2000 addeundum. If you do not feel comfortable creating a boot disk 
under Stacker or DoubleSpace, contact STAC Electronics or Microsoft 
for technical support.

VII. GAME PLAY ISSUES

Saved Cities
------------
For your simulating pleasure, we have included several saved cities
created by various Maxis employees. They are located in your 
SimCity 2000 directory.

Micro-Simulators 
---------------- 
When querying some structures, you get local statistics about that 
structure. For instance, querying on a Police Station will tell you 
how many crimes and arrests were handled by that station, and querying 
on a school will tell you how many teachers and students are attending 
that school as well as the average grade of the students. Most placeable 
structures (police, fire, schools, colleges, power plants, the Mayor's 
House, arcologies, etc.)have these micro-simulators. Some 
structures share one micro-simulator for all the structures placed. 
Things like the bus system, railroad depots, marinas, libraries, 
windmills, and hydroelectric power plants among others have one
micro-simulator for each category (one micro-simulator for all the bus 
stations, one for all the railroad depots, etc.). Where is this 
all headed, you ask? Well, each city can only have 150 
microsimulators in it. If you go beyond that, the structure you place 
will still affect the simulator globally (police stations will still 
stop crime, bus stations will still carry passengers, arcologies will 
still hold people), but you just won't be able to see any local 
information on those structures. This isn't going to harm your city 
in any way. We're telling you this because it's pretty easy to run 
out of micro-simulators in a large city and we don't want you thinking 
something's wrong. 
 
Terrain Editing 
--------------- 
If you are building a city and go into the terrain edit mode, your 
city will disappear, but any trees or water that you have placed in 
the city will show up in terrain edit mode. Also, if you have placed 
a bridge or other structure that automatically builds landfill, the 
landfill will also show up in terrain edit mode. These can be removed 
with the Lower Terrain tool. 
 
Airports 
-------- 
Keep in mind when building an airport that it needs space for a 
runway, or it will not build. The minimum usable airport space is 
2 x 6 tiles. Your best bet is to build the airport in 4 x 6 tile 
increments. And make sure no tall buildings are nearby; SimCity 2000 
pilots are not known for their building-avoidance skills! 
In addition, make sure that your airport is blanketed with power 
lines. Airports may not initially build unless they are receiving 
power to certain tiles. 

Newspapers
----------
If you are running low on hard drive space, you may experience a 
problem where multiple newspaper stories are open at one time.  You
will need at least 300KB free hard drive space (on the drive that
SimCity 2000 is installed to) before starting the game, and this 
will fix the problem.  If you do get multiple stories, you can clear
them by pressing 'ENTER'.
If you are running into low memory situations, the Newspaper menu item
may gray out.  Don't be alarmed; it won't hurt anything.

Importing Cities From SimCity Classic and SimCity 2000 Mac 
---------------------------------------------------------- 
You can load saved cities from both SimCity Classic and SimCity 2000 
Mac into SimCity 2000 DOS. For importing purposes, SimCity Windows
and SimCity DOS files are identical.
To import SimCity Classic DOS and SimCity 2000 Mac saved games, 
rename the file so that the extension is ".SC2". If the file is from 
SimCity Classic DOS, SimCity 2000 will ask you if you wish to convert 
the file to SimCity 2000 format. The conversion will not change the 
original file unless you save it over the original file.
To convert SimCity 2000 DOS files for use in SimCity 2000 Mac you 
will need to give the file a Filetype and Creator for the Macintosh. The
Filetype should be "CITY" and the Creator should be "SCDH".
This can be done with ResEdit, Access PC, or one of several other
PC to Mac conversion utilities.
SimCity Classic Mac cities must be imported into SimCity 2000 Mac before
they can be loaded into SimCity 2000 DOS. Not doing so will result in
a "Not an IFF �ile" error message.

Hot Key�
--------
SHIFT KEY-  
1. While placing items, pressing the Shift key before releasing the mouse 
button will cancel placement of the item.  
2. Holding down the Shift key while clicking on a� item in the city 
window will open the Query window for that specific item.  
3. Holding down the Shift key while clicking on a button or entry in 
a window will open a help description for that item. 
 
CTRL - temporarily turns the current cursor into the Bulldoze Tool. 
HOME - zooms in one level on your city 
END - zooms out one level on your city 
DEL - rotates your city view to the left by 90 degrees 
PAGE DOWN - rotates your city view to the right by 90 degrees 
Cursor Keys - scroll around your city 

VIII. TROUBLESHOOTING

I Get An "Error 35"
-------------------
This message usually shows up if you have certain ATI cards and have
not loaded the MW_ATIUP program. See the ATI entry in Section II above
for more information.

SimCity 2000 Locks Up
---------------------
This is more than likely the result of a conflict between SimCity 2000
and a memory-resident program that is being loaded in your AUTOEXEC.BAT
or CONFIG.SYS files. The best solution to this is to create a boot disk
as outlined in the addendum. If this does not help, try running the 
INSTALL program in the SimCity 2000 directory and selecting No Sound
Effects. If this doesn't help, call Maxis Technical Support at the 
number listed on the Maxis Maxims card included in your SimCity 2000
box.

SimCity 2000 Install Program Crashes
------------------------------------
This is also probably a conflict with a loaded memory resident program.
Try making a boot disk as per the addendum. Ignore the "Bad Command or
Filename" message that appears when using the boot disk for
installation. Also try running the INSTALL program with no mouse driver 
loaded. See your mouse manual for information on disabling the mouse.

I Get A "Microsoft Compatible Mouse Not Found" Message
------------------------------------------------------
This message is usually the result of one of two problems. Most likely,
a mouse driver has not been loaded. SimCity 2000 needs a DOS mouse
driver to run (as opposed to a Microsoft Windows mouse driver). This
driver along with instructions on how to load it should have come with
your mouse. The less likely problem is that the mouse driver is being
correctly loaded, but it is an older version that is not supported. You
should contact the manufacturer (or dealer) of your mouse to get a more
up-to-date mouse driver.

I Have A Diamond Stealth/Viper And Get Funny Lines On My Display
----------------------------------------------------------------
This is a problem with SimCity 2000 and some early versions of the
Diamond drivers. There are software patches available for both the
Stealth and Viper to alleviate this problem. The Stealth patch is
available as a software program called STLBIOS.EXE or as a hardware
upgrade. For the Diamond Viper a software upgrade called VPRM202.EXE
will contain a patch. All of these are available from Diamond.

Thanks for buying SimCity 2000 
We hope you enjoy playing it as much as we enjoyed creating it! 
[EOF] 
------------------------------------------------------------------------- 
 

